$(function(){
  $.scrollIt();
});